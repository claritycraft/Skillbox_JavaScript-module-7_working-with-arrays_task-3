const products = ["Хлеб", "Молоко", "Яблоки", "Сыр"];

function renderProductList() {
    const productList = document.getElementById("product-list");
    productList.innerHTML = "";  // Очищаем список перед добавлением новых элементов

    const sortedProducts = [...products].sort((a, b) => a.localeCompare(b));

    sortedProducts.forEach((product, index) => {
        const li = document.createElement("li");
        // Добавляем нумерацию и точку
        li.textContent = `${index + 1}) ${product}`;
        productList.appendChild(li);
    });
}

function addProduct() {
    const productName = prompt("Введите название товара:");

    if (!productName || productName.trim() === "") {
        alert("Название товара не введено!");
        return;
    }

    products.push(productName.trim());  // Добавляем новый товар в массив
    renderProductList();  // Перерисовываем список
}

document.getElementById("add-product-button").addEventListener("click", addProduct);

// Инициализация списка товаров при загрузке страницы
renderProductList();

