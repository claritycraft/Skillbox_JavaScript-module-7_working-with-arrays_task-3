// 1. Получаем контейнер
const container = document.querySelector(".container");

// 2. Создаём массив с продуктами
const foodCart = [
  "Абрикосы",
  "Бананы",
  "Виноград",
  "Вода",
  "Гранаты",
  "Лимоны",
  "Мандарины",
  "Персики",
  "Рис",
  "Сок",
];

// 3. Создаём кнопку
const addBtn = document.createElement("button");
addBtn.textContent = "Добавить товар";
addBtn.classList.add("add-button");
container.append(addBtn); // добавляем в контейнер

// 4. Создаём список
const listEl = document.createElement("ul");
listEl.classList.add("food-list");
container.append(listEl); // добавляем в контейнер

// 5. Функция рендера
function renderList(foodCart) {
  listEl.innerHTML = "";
  for (let i = 0; i < foodCart.length; i++) {
    const liEl = document.createElement("li");
    liEl.textContent = `${i + 1}) ${foodCart[i]}`;
    listEl.append(liEl);
  }
}

// 6. Сортировка пузырьком
function sort(foodCart) {
  for (let i = 0; i < foodCart.length; i++) {
    for (let j = 0; j < foodCart.length - 1; j++) {
      if (foodCart[j] > foodCart[j + 1]) {
        let temp = foodCart[j];
        foodCart[j] = foodCart[j + 1];
        foodCart[j + 1] = temp;
      }
    }
  }
  return foodCart;
}

// 7. Обработчик кнопки
addBtn.onclick = function () {
  const addItem = prompt("Добавить товар");
  if (!addItem || addItem.trim() === "") {
    alert("Название не введено");
    return;
  }
  foodCart.push(addItem);
  const sortedCart = sort(foodCart);
  renderList(sortedCart);
};

// 8. Первичный рендер
renderList(foodCart);
